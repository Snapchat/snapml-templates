// -----JS CODE-----
// @input int renderOrder
// @input Asset.Material deviceCamera
// @input Asset.Material background
// @input Asset.Material spinner

// Import module

/* Destruction Helper Part (to avoid issues with modules in Fiji) */

/**
 * @class
 * @param {ScriptComponent} inputScript 
 */
function DestructionHelper(inputScript) {
    var manager = this;
    manager._isAlive = true;
    manager._toDestroy = [];
    inputScript.createEvent("OnDestroyEvent").bind(function() {
        manager._isAlive = false;
        manager._toDestroy.forEach(function(element) {
           if(!isNull(element)) {
                element.destroy();
           } 
        });
    })
};

/**
 * Takes a function that will only be called if the script has not been destroyed.
 * Returns a function to be passed to other API.
 * @template {function} T
 * @param {T} callback 
 * @returns {T}
 */
DestructionHelper.prototype.safeCallback = function(callback) {
    var manager = this;
    return function() {
        if(manager._isAlive) {
            callback.apply(null, arguments);
        }
    };
}

/**
 * Creates a Component of type `type` on the given obj. It will be destroyed when the script is.
 * @template {keyof ComponentNameMap} T
 * @param {SceneObject} obj 
 * @param {T} type 
 * @returns {ComponentNameMap[T]} 
 */
DestructionHelper.prototype.createComponent = function(obj, type) {
    var comp = obj.createComponent(type);
    this._toDestroy.push(comp);
    return comp;
}

/**
 * Creates a SceneObject with the given parent. It will be destroyed when the script is.
 * @param {SceneObject} parent 
 * @returns {SceneObject}
 */
DestructionHelper.prototype.createSceneObject = function(parent) {
    var obj = global.scene.createSceneObject("");
    obj.setParent(parent);
    this._toDestroy.push(obj);
    return obj;
}

var manager = new DestructionHelper(script);

var rootSO = script.getSceneObject();

var deviceCameraSO = manager.createSceneObject(rootSO);
var backgroundSO = manager.createSceneObject(rootSO);
var spinnerSO = manager.createSceneObject(rootSO);

var deviceCameraST = manager.createComponent(deviceCameraSO, "Component.ScreenTransform");
var backgroundST = manager.createComponent(backgroundSO, "Component.ScreenTransform");
var spinnerST = manager.createComponent(spinnerSO, "Component.ScreenTransform");

spinnerST.anchors = Rect.create(0, 0, 0, 0);
spinnerST.offsets = Rect.create(-0.75, 0.75, -0.75, 0.75);

var deviceCameraImage = manager.createComponent(deviceCameraSO, "Component.Image");
var backgroundImage = manager.createComponent(backgroundSO, "Component.Image");
var spinnerImage = manager.createComponent(spinnerSO, "Component.Image");

deviceCameraSO.layer = rootSO.layer;
backgroundSO.layer = rootSO.layer;
spinnerSO.layer = rootSO.layer;

deviceCameraImage.stretchMode = StretchMode.Stretch;
backgroundImage.stretchMode = StretchMode.Stretch;
spinnerImage.stretchMode = StretchMode.Fill;

deviceCameraImage.renderOrder = script.renderOrder;
backgroundImage.renderOrder = script.renderOrder;
spinnerImage.renderOrder = script.renderOrder;

deviceCameraImage.mainMaterial = script.deviceCamera.clone();
backgroundImage.mainMaterial = script.background.clone();
spinnerImage.mainMaterial = script.spinner.clone();