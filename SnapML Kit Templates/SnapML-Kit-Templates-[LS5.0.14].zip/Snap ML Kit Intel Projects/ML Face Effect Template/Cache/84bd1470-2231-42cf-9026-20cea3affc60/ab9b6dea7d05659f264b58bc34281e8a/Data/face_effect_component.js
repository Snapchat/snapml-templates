// -----JS CODE-----

// @input int renderOrder { "label": "Render Order", "Hint": "Render Order for Image Mesh Visual" }
/** @type {number} */
var renderOrder = script.renderOrder;

//@ui {"widget":"separator"}

//@input Asset.MLAsset asset { "label": "Model" }
/** @type {MLAsset} */
var model = script.asset;

// @input bool autoRun { "label": "Auto run" }
// @input bool autoBuild { "label": "Auto build" }

// @ui {"widget":"separator"}

//@input int faceIndex {"label": "Face Index", "min": 0}
/** @type {number} */
var faceIndex = script.faceIndex;

//@input Asset.Texture inputTexture
/** @type {Texture} */
var inputTexture = script.inputTexture;

//@input Asset.Material material
/** @type {Material} */
var material = script.material;

// @input Asset.Texture opacityTex

function checkInputs() {
    var success = true;
    if (!script.asset) {
        success = false;
        print("Error: Missing ML Model, please provide MLAsset.")
    }
    
    if (!script.inputTexture) {
        success = false;
        print("Error: Missing Input Texture, please provide Face Crop Texture with desired input texture.")
    }
    
    return success;
}

if (!checkInputs()) {
    return;
}


var currentState = MachineLearning.ModelState.NotReady;

/* CONSTANTS */

var ML_MODEL_INPUT_NAME = "data";
var FACE_CROP_SCALE = new vec2(1.25, 1.25); 
var FACE_CENTER_MOUTH_WEIGHT = 0.1;

var WARP_INPUT = true;
var WARP_OUTPUT = false;
    
/* CONSTANTS END */

// Import module

/* Destruction Helper Part (to avoid issues with modules in Fiji) */

/**
 * @class
 * @param {ScriptComponent} inputScript 
 */
function DestructionHelper(inputScript) {
    var manager = this;
    manager._isAlive = true;
    manager._toDestroy = [];
    inputScript.createEvent("OnDestroyEvent").bind(function() {
        manager._isAlive = false;
        manager._toDestroy.forEach(function(element) {
           if(!isNull(element)) {
                element.destroy();
           } 
        });
    })
};

/**
 * Takes a function that will only be called if the script has not been destroyed.
 * Returns a function to be passed to other API.
 * @template {function} T
 * @param {T} callback 
 * @returns {T}
 */
DestructionHelper.prototype.safeCallback = function(callback) {
    var manager = this;
    return function() {
        if(manager._isAlive) {
            callback.apply(null, arguments);
        }
    };
}

/**
 * Creates a Component of type `type` on the given obj. It will be destroyed when the script is.
 * @template {keyof ComponentNameMap} T
 * @param {SceneObject} obj 
 * @param {T} type 
 * @returns {ComponentNameMap[T]} 
 */
DestructionHelper.prototype.createComponent = function(obj, type) {
    var comp = obj.createComponent(type);
    this._toDestroy.push(comp);
    return comp;
}

/**
 * Creates a SceneObject with the given parent. It will be destroyed when the script is.
 * @param {SceneObject} parent 
 * @returns {SceneObject}
 */
DestructionHelper.prototype.createSceneObject = function(parent) {
    var obj = global.scene.createSceneObject("");
    obj.setParent(parent);
    this._toDestroy.push(obj);
    return obj;
}

var manager = new DestructionHelper(script);

/**@type {Boolean} */
var loadingStatus = false;
/**@type {Image} */
var imageComp;
/**@type {RectangleSetter} */
var rectComp;
/**@type {MLComponent} */
var mlComp;
/**@type {ScreenTransform} */
var screenTransform;
/**@type {Head} */
var head = createHeadComponent();

/**
 * @returns Head
 */
 function createHeadComponent() {
    var headSo = manager.createSceneObject(null);
    headSo.name = "Head Binding " + faceIndex;
    
    var headComp = headSo.createComponent("Head");
    headComp.faceIndex = faceIndex;
    return headComp;
}

function validation(so) {
    screenTransform = so.getComponent("Component.ScreenTransform");
    if (!screenTransform) {
        print("Warning, please add this component to Screen Image");
    }
    if (screenTransform && !screenTransform.isInScreenHierarchy()) {
        print("Warning, scene object should be a part of screen hierarchy, please create Screen Image and attach this component");
    }
}

function getFaceCropTexture() {
    return inputTexture;
}

function setupImage(so) {
    // To make sure image isn't presented untill rect comp is enabled
    screenTransform = so.getComponent("Component.ScreenTransform");    
    screenTransform.anchors = Rect.create(0, 0, 0, 0);
    screenTransform.offset = Rect.create(0, 0, 0, 0);
    
    // Create Image component
    imageComp = manager.createComponent(so, "Component.Image");
    imageComp.mainMaterial = material.clone();
    imageComp.renderOrder = renderOrder;
    
    // Adjust ML output to crop rect
    rectComp = manager.createComponent(so, "Component.RectangleSetter");
    rectComp.cropTexture = getFaceCropTexture(); 
    
    //hide image before model is loaded
    imageComp.enabled = false;   
    rectComp.enabled = false;
}

function setupML(so) {
    // Creating ML Component
    mlComp = manager.createComponent(so, "Component.MLComponent");
    
    mlComp.autoRun = false;
    mlComp.autoBuild = false;

    mlComp.model = model;
    //configure outputs
    var mlOutputs = mlComp.getOutputs();

    mlOutputs.forEach(function (mlOutput) { mlOutput.mode = MachineLearning.OutputMode.Texture });
}   

function getCameraRenderOrder(so) {
    if (!so) {
        print("Warning! Please, add this component to hierarchy withing ortographic camera.")
        return -1;
    }    
    
    var camera = so.getComponent("Component.Camera");
    
    if (camera) {
        return camera.renderOrder;
    } else {
        return getCameraRenderOrder(so.getParent());
    }
}

function getCameraLayer(so) {
    if (!so) {
        print("Warning! Please, add this component to hierarchy withing ortographic camera.")
        return -1;
    }    
    
    var camera = so.getComponent("Component.Camera");
    
    if (camera) {
        return camera.renderLayer;
    } else {
        return getCameraLayer(so.getParent());
    }
}

function init() {
    var so = script.getSceneObject();
    
    validation(so);
    setupImage(so);
    setupML(so);
    
    //safe callback wrapper
    mlComp.onLoadingFinished = manager.safeCallback(function() { onLoadingFinished(mlComp.model.getMetadata()) });

    mlComp.inferenceMode = MachineLearning.InferenceMode.Auto;

    if (script.autoBuild) {
        //build with default settings
        mlComp.build([]);
    }
    
    mlComp.renderOrder = getCameraRenderOrder(so) - 1;    
    so.layer = getCameraLayer(so);
}

var updater = script.createEvent("UpdateEvent");
updater.enabled = false;
updater.bind(onUpdate);

/**
 * Set model imputs, set output textures to material properties, set settings
 */
function onLoadingFinished(settings) {
    //configure inputs
    
    script.inputTexture.control.textureScale = FACE_CROP_SCALE;
    script.inputTexture.control.faceCenterMouthWeight = FACE_CENTER_MOUTH_WEIGHT; 
    script.inputTexture.control.faceIndex = script.faceIndex;    
    
    rectComp.enabled = true;
    imageComp.mainPass.overallintensity = 1;
    
    if (settings.crop) {
        if (settings.crop.scale.x && settings.crop.scale.y) {
            script.inputTexture.control.textureScale = 
                new vec2(settings.crop.scale.x, settings.crop.scale.y);
        }
        
        if (settings.crop.open_mouth_weight) {
            script.inputTexture.control.faceCenterMouthWeight = 
                settings.crop.open_mouth_weight;    
        }
    }
    
    mlComp.getInput(ML_MODEL_INPUT_NAME).texture = getFaceCropTexture();
    mlComp.enabled = true;
    
    //get shader settings corresponding to this ML model 
    configureMaterial(
        imageComp.mainPass, 
        inputTexture.control.inputTexture,
        mlComp.getOutputs(),
        mlComp.model.getMetadata());

    currentState = MachineLearning.ModelState.Idle;
    onLoadingCallbacks.forEach(function(cb) {
        cb();
    });    

    mlComp.onRunningFinished = function() { 
        if (currentState == MachineLearning.ModelState.Running) {
            if (!isNull(imageComp)) {
                imageComp.enabled = true; 
            }
        }
    }    
    
    if (script.autoRun) {
        //create update event to update crop   
        currentState = MachineLearning.ModelState.Running;
        updater.enabled = true;
    }
}

function onUpdate() {
    if (head.getFacesCount() > faceIndex) {
        // run once on render if head is tracking
        mlComp.runScheduled(false, MachineLearning.FrameTiming.OnRender, MachineLearning.FrameTiming.OnRender);              
    } else {
        if (!isNull(imageComp)) {
            imageComp.enabled = false;
        }
    }
}


function configureMaterial(pass, inputTexture, outputs, settings) {
    // connecting textures to material's input
    pass.inputTex = inputTexture;
    pass.opacityTex = script.opacityTex;
    
    var replace_slashes = function(str) {
        return str.replace('/', '_');
    }    
    
    const output_map = {
        "output_0": "baseTex",
        "output_1": "output_1"
    }
    
    // script input doesn't support slashes in names
    for (var i = 0; i < outputs.length; i++) {
        pass[output_map[replace_slashes(outputs[i].name)]] = outputs[i].texture;
    }    
    
    // filling color and warp statistics
    const defaultColorSettings = {
        "r_max": 1.0, "g_max": 1.0, "b_max": 1.0, "a_max": 1.0,
        "r_min": 0, "g_min": 0, "b_min": 0, "b_min": 0
    };
    
    const defaultWarpSettings = {
        "x_max": 0, "y_max": 0,
        "x_min": 0, "y_min": 0
    };

    if (settings.rgba_stats) {
        colorSettings = settings.rgba_stats;
    }
    
    if (settings.source_warp_stats) {
        warpSettings = settings.source_warp_stats;
    }

    var colorMax = new vec4(colorSettings.r_max, colorSettings.g_max, colorSettings.b_max, colorSettings.a_max);
    var colorMin = new vec4(colorSettings.r_min, colorSettings.g_min, colorSettings.b_min, colorSettings.a_min);
    var warpMax = new vec4(warpSettings.x_max, warpSettings.y_max, 1.0, 1.0);
    var warpMin = new vec4(warpSettings.x_min, warpSettings.y_min, 1.0, 1.0);

    pass.colorMax = colorMax;
    pass.colorMin = colorMin;

    pass.warpMax = warpMax;
    pass.warpMin = warpMin;
    
    if (settings.warp_input) {
        pass.warpInput = settings.warp_input;
    } else {
        pass.warpInput = WARP_INPUT;    
    }
    
    if (settings.warp_output) {
        pass.warpOutput = settings.warp_output;
    } else {
        pass.warpOutput = WARP_OUTPUT;
    }
}

init();

/* API Methods */

function run() {
    if (currentState == MachineLearning.ModelState.Running) {
        print("Model is already running");
        return;
    }
    
    if (currentState == MachineLearning.ModelState.Loading) {
        print("Model can't run until is loaded");
        return;
    } 
    
    if (currentState == MachineLearning.ModelState.NotReady) {
        print("To run the model you need to call build method or enable auto build option in Component UI.")
        return;    
    }
    
    updater.enabled = true;
    currentState = MachineLearning.ModelState.Running;
}

function stop() {
    if (currentState == MachineLearning.ModelState.Running) {
        updater.enabled = false;
        currentState = MachineLearning.ModelState.Idle;
        imageComp.enabled = false;
    } else {
        print("Model can't stop, because it's not running.");
    }
}

function build(autoRun) {
    if (currentState == MachineLearning.ModelState.NotReady) {
        script.autoRun = true;
        mlComp.build([]);
    } else {
        print("Component could be built only once.");
    }
}

function state() {
    return currentState;
}   

var onLoadingCallbacks = [];

function addOnLoadingFinishedCallback(cb) {
    if (currentState == MachineLearning.ModelState.Running || currentState == MachineLearning.ModelState.Idle) {
        cb();
    }
    
    onLoadingCallbacks.push(cb);
}

Object.defineProperties(script, {
    run: {
        get: function() {
            return run;
        }
    },
    stop: {
        get: function() {
            return stop;
        }
    },
    build: {
        get: function() {
            return build;
        }
    },
    state: {
        get: function() {
            return currentState;
        }
    },
    addOnLoadingFinishedCallback: {
        get: function() {
            return addOnLoadingFinishedCallback;
        }
    },
    intensity: {
        get: function() {
            if (!isNull(imageComp)) {
                return imageComp.mainPass.textureintensity;
            } else {
                return null;
            }
        },
        set: function(newOpacity) {
            if (!isNull(imageComp)) {
                imageComp.mainPass.textureintensity = newOpacity;
                imageComp.mainPass.warp_intensity = newOpacity;
            }
        }
    }
});