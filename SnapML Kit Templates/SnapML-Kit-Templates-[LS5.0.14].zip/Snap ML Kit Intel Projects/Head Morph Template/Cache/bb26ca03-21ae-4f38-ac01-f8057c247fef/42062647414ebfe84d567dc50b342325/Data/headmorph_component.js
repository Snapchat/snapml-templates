// @input Asset.RenderMesh mesh
// @input Asset.RenderMesh faceMesh
// @input Asset.Texture texture
// @input Asset.RenderMesh SkullAndFaceMesh
// @input Asset.Material material
// @input int faceIndex
// @input int renderOrder 

// @input Asset.RenderMesh faceMeshIn
// @input Asset.Material cameraToUv
// @input Asset.Texture reprojRT

// @input float geometryWeight = 1.0 {"widget":"slider", "min":0.0, "max":1.0, "step":0.01}
// @input float textureWeight = 1.0 {"widget":"slider", "min":0.0, "max":1.0, "step":0.01}
// @input Asset.Texture alphaMap
// @input Asset.Texture inputTexture

// Import module

/* Destruction Helper Part (to avoid issues with modules in Fiji) */

/**
 * @class
 * @param {ScriptComponent} inputScript 
 */
function DestructionHelper(inputScript) {
    var manager = this;
    manager._isAlive = true;
    manager._toDestroy = [];
    inputScript.createEvent("OnDestroyEvent").bind(function() {
        manager._isAlive = false;
        manager._toDestroy.forEach(function(element) {
           if(!isNull(element)) {
                element.destroy();
           } 
        });
    })
};

/**
 * Takes a function that will only be called if the script has not been destroyed.
 * Returns a function to be passed to other API.
 * @template {function} T
 * @param {T} callback 
 * @returns {T}
 */
DestructionHelper.prototype.safeCallback = function(callback) {
    var manager = this;
    return function() {
        if(manager._isAlive) {
            callback.apply(null, arguments);
        }
    };
}

/**
 * Creates a Component of type `type` on the given obj. It will be destroyed when the script is.
 * @template {keyof ComponentNameMap} T
 * @param {SceneObject} obj 
 * @param {T} type 
 * @returns {ComponentNameMap[T]} 
 */
DestructionHelper.prototype.createComponent = function(obj, type) {
    var comp = obj.createComponent(type);
    this._toDestroy.push(comp);
    return comp;
}

/**
 * Creates a SceneObject with the given parent. It will be destroyed when the script is.
 * @param {SceneObject} parent 
 * @returns {SceneObject}
 */
DestructionHelper.prototype.createSceneObject = function(parent) {
    var obj = global.scene.createSceneObject("");
    if (parent) {
        obj.setParent(parent);
    }
    this._toDestroy.push(obj);
    return obj;
}

function getCameraRenderOrder(so) {
    if (!so) {
        print("Warning! Please, add this component to hierarchy withing ortographic camera.")
        return -1;
    }    
    
    var camera = so.getComponent("Component.Camera");
    
    if (camera) {
        return camera.renderOrder;
    } else {
        return getCameraRenderOrder(so.getParent());
    }
}

var manager = new DestructionHelper(script);

var so = script.getSceneObject();

var soIn = manager.createSceneObject(so);
var soOut = manager.createSceneObject(so);
var reprojSo = manager.createSceneObject(null);

soOut.layer = so.layer;

var renderMeshIn = manager.createComponent(soIn, "Component.RenderMeshVisual");

renderMeshIn.mesh = script.faceMeshIn;
renderMeshIn.mainMaterial = script.cameraToUv.clone();
renderMeshIn.mainPass.Tweak_N17 = script.inputTexture;
renderMeshIn.mainPass.zeroParam = 0;
renderMeshIn.mainPass.plusOneParam = 1;
renderMeshIn.mainPass.minusOneParam = -1;
renderMeshIn.mainPass.Tweak_N15 = 0.3;

renderMeshIn.setRenderOrder(script.renderOrder);

renderMeshIn.mesh.control.faceIndex = script.faceIndex;

var renderMeshVisual = manager.createComponent(soOut, "Component.RenderMeshVisual");

renderMeshVisual.mesh = script.faceMesh;
renderMeshVisual.mainMaterial = script.material.clone();

renderMeshVisual.mesh.control.faceIndex = script.faceIndex;

renderMeshVisual.blendNormals = true;
renderMeshVisual.blendShapesEnabled = true;
renderMeshVisual.setBlendShapeWeight("ExternalFaceMesh", script.geometryWeight);


renderMeshVisual.mainPass.baseTex = script.texture;
renderMeshVisual.mainPass.reproj = script.reprojRT;
renderMeshVisual.mainPass.Tweak_N0 = script.textureWeight;
renderMeshVisual.mainPass.Tweak_N5 = script.alphaMap;

renderMeshVisual.setRenderOrder(script.renderOrder);

reprojSo.getTransform().setLocalPosition(new vec3(0, 0, 40));

var reprojCameraComponent = manager.createComponent(reprojSo, "Component.Camera");
reprojCameraComponent.type = Camera.Type.Perspective;

reprojCameraComponent.renderTarget = script.reprojRT;
reprojCameraComponent.renderOrder = getCameraRenderOrder(so) - 1;
reprojCameraComponent.renderLayer = LayerSet.makeUnique();
soIn.layer = reprojCameraComponent.renderLayer;

Object.defineProperties(script, {
    renderOrder: {
        get: function() {
            if (!isNull(renderMeshVisual)) {
                return renderMeshVisual.getRenderOrder();
            } else {
                return null;
            }
        },
        set: function(value) {
            if (!isNull(renderMeshVisual)) {
                renderMeshVisual.setRenderOrder(value);
            }
            if (!isNull(renderMeshIn)) {
                renderMeshIn.setRenderOrder(value);
            }
        }
    },
    faceIndex: {
        get: function() {
            if (!isNull(renderMeshVisual)) {
                return renderMeshVisual.mesh.control.faceIndex;
            }
        },
        set: function(value) {
            if (!isNull(renderMeshIn)) {
                renderMeshIn.mesh.control.faceIndex = value;
            }
            if (!isNull(renderMeshVisual)) {
                renderMeshVisual.mesh.control.faceIndex = value;
            }
        }
    },
    geometryWeight: {
        get: function() {
            if (!isNull(renderMeshVisual)) {
                return renderMeshVisual.getBlendShapeWeight("ExternalFaceMesh");
            } else {
                return null;
            }
        },
        set: function(value) {
            if (!isNull(renderMeshVisual)) {
                renderMeshVisual.setBlendShapeWeight("ExternalFaceMesh", value);
            }
        }
    },
    textureWeight: {
        get: function() {
            if (!isNull(renderMeshVisual)) {
                return renderMeshVisual.mainPass.Tweak_N0;
            } else {
                return null;
            }
        },
        set: function(value) {
            if (!isNull(renderMeshVisual)) {
                renderMeshVisual.mainPass.Tweak_N0 = value;
            }
        }
    }
});