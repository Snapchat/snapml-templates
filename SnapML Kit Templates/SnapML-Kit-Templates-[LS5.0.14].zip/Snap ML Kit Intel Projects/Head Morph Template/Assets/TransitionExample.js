// @input Component.ScriptComponent headmorphComponent

let transitionValue = 0;
const step = 0.04;

const updater = script.createEvent("UpdateEvent");
updater.bind(() => {
    if (transitionValue + step > 1) {
        updater.enabled = false;
        return;
    }    
    
    transitionValue += step;
    
    script.headmorphComponent.textureWeight = transitionValue;
    script.headmorphComponent.geometryWeight = transitionValue;
});

updater.enabled = false;

script.createEvent("TapEvent").bind(() => {
    transitionValue = 0;
    updater.enabled = true;
});